//
//  AGBusinessman.m
//  NotificationTest (Lesson 10)
//
//  Created by Anton Gorlov on 19.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGBusinessman.h"
#import "AGGovernment.h"
@implementation AGBusinessman
- (instancetype)init
{
    self = [super init];
    if (self) {
        NSNotificationCenter*notcentr=[NSNotificationCenter defaultCenter];
        //бизнесмену нужны налоги и покупная способность,подпишемся на нотификацию.
        [notcentr addObserver:self //обьект.
                     selector:@selector(taxLevelChangeNotification:) // метод.
                         name:AGGovernmentTaxLevelDidChangeNotification object:nil];//подписан на уровень налогов.
        [notcentr addObserver:self
                     selector:@selector(averagePriceChangeNotification:)
                         name:AGGovernmentAveragePriceDidChangeNotification object:nil];
        
        //сворачиваем приложение
        [[NSNotificationCenter defaultCenter]addObserver:self
                 selector:@selector(didEnterBackgroundNotification:)
                name:NSExtensionHostDidEnterBackgroundNotification
                                                  object:nil];
        //разворачиваем приложение
        [[NSNotificationCenter defaultCenter]addObserver:self
                selector:@selector(willEnterForegroundNotification:)
                name:NSExtensionHostWillEnterForegroundNotification
                object:nil];
    }
    return self;
}
-(void) dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self ];
}
//2 метода для сварачивания/разворачивания приложения.
-(void) didEnterBackgroundNotification:(NSNotification*) notification {
    NSLog(@"Businessman goes to sleep");
}
-(void) willEnterForegroundNotification:(NSNotification*) notification {
NSLog(@"Businessman woke up");
}
#pragma mark --Notification--
/* Уровень Ученик
-(void) taxLevelChangeNotification:(NSNotification*) notification {
    NSNumber*value=[notification.userInfo objectForKey:AGGovernmentTaxLevelUserInfoKey];
    float taxLevel=[value floatValue];
    if (taxLevel>self.taxLevel) {
        NSLog(@"A Businessman says the tax level is horrible!");
    }else{
     NSLog(@"A Businessman says the Good tax level!");
    }
    self.taxLevel=taxLevel;
}
-(void) averagePriceChangeNotification: (NSNotification*) notification {
    NSNumber*value=[notification.userInfo objectForKey:AGGovernmentAveragePriceUserInfoKey];
    float averagePrice=[value floatValue];
    if (averagePrice>self.averagePrice) {
        NSLog(@"Businessman averagePrice it's NOT good");
    }else {
        NSLog(@"Businessman averagePrice it's VERY good");
    }
      self.averagePrice=averagePrice;
}
*/

//уровень Умничка

-(void) taxLevelChangeNotification:(NSNotification*) notification {
    NSNumber*value=[notification.userInfo objectForKey:AGGovernmentTaxLevelUserInfoKey];
    float taxLevel=[value floatValue];
    _taxLevelIncrease=(taxLevel/(self.taxLevel/100))-100; //внутр. переменная =новый уров налогов/старый ур /100
    if (_taxLevelIncrease<0) {
        NSLog(@"Businessman are NOT happy! Taxevel increased by %.2f%%",(-1)*_taxLevelIncrease);
    }else{
        NSLog(@"Businessman are happy! Taxevel increased by %.2f%%",_taxLevelIncrease);
    }
    self.taxLevel=taxLevel;
}
-(void) averagePriceChangeNotification: (NSNotification*) notification {
    NSNumber*value=[notification.userInfo objectForKey:AGGovernmentAveragePriceUserInfoKey];
    float averagePrice=[value floatValue];
    _inflationRatePrice=(averagePrice/(self.averagePrice/100))-100;
    if (_inflationRatePrice > 0 &&_taxLevelIncrease < 0) {
         NSLog(@"Businessman says :Our government is stupid!");
    }else if (_inflationRatePrice < 0 && _taxLevelIncrease > 0) {
        NSLog(@"Businessman says : Our government is excellent");
    }else {
        NSLog(@"Businessman says : Our government is not bad");
    }
    self.averagePrice=averagePrice;
}


@end
