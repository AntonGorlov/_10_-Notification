//
//  AppDelegate.m
//  NotificationTest (Lesson 10)
//
//  Created by Anton Gorlov on 19.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"
#import "AGGovernment.h"
#import "AGDoctor.h"
#import "AGBusinessman.h"
#import "AGPensioner.h"
#import "AGFakeAppDelegate.h"

@interface AppDelegate () //категория в () можно имя,но она по умолчанию
@property (strong,nonatomic) AGGovernment* government;
@property (strong,nonatomic) AGDoctor* doctor;
@property (strong,nonatomic) AGPensioner* pensioner;
@property (strong,nonatomic) AGBusinessman* businessman;
@property (strong,nonatomic) AGFakeAppDelegate* fakeAppDelegate;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    [[NSNotificationCenter defaultCenter]addObserver:self //подписка на нотификацию налогов
                                            selector:@selector(governmentNotification:)
                                                name:AGGovernmentTaxLevelDidChangeNotification
                                              object:nil];
    
    self.government=[[AGGovernment alloc]init];
    self.doctor=[[AGDoctor alloc]init];
    self.pensioner=[[AGPensioner alloc]init];
    self.businessman=[[AGBusinessman alloc]init];
    self.fakeAppDelegate=[[AGFakeAppDelegate alloc]init];
    NSLog(@"UIApplication didFinishLaunchingNotification");
   
    
    AGDoctor*doctor1=[[AGDoctor alloc]init];
    AGDoctor*doctor2=[[AGDoctor alloc]init];
    
    
    //выставляем всем одну зп.
    
    doctor1.salary=doctor2.salary=self.government.salary;
    doctor1.salary=doctor2.salary=self.government.averagePrice;
    
    AGBusinessman*businessman1=[[AGBusinessman alloc]init];
    AGBusinessman*businessman2=[[AGBusinessman alloc]init];
    
    businessman1.taxLevel=businessman2.taxLevel=self.government.taxLevel;
    businessman1.taxLevel=businessman2.taxLevel=self.government.averagePrice;
    
    AGPensioner*pensioner1=[[AGPensioner alloc]init];
    AGPensioner*pensioner2=[[AGPensioner alloc]init];
    
  
    pensioner1.pension=pensioner2.pension=self.government.pension;
    pensioner1.pension=pensioner2.pension=self.government.averagePrice;
    
    
    //изменяем показатели (поменялся налог и т.д)
    
    NSLog(@" ----------taxLevel!!!");
    self.government.taxLevel=5.5;
       NSLog(@" ----------salary!!!");
    self.government.salary=1100;  //ЗП на 10% увел
    NSLog(@" ----------averagePrice!!!");
    self.government.averagePrice=15; //средняя цена на 50%
     NSLog(@"-----------pension!!!");
    self.government.pension=550;
    
       NSLog(@" ----------salary!!!");
   //Для доктора
    self.government.salary=1000;
  
    
       NSLog(@" ----------taxLevel!!!");
   //Для бизнесмена.
    self.government.taxLevel=6.f;
  
    
       NSLog(@"-----------pension!!!");
    //Для пенсионера.
    self.government.pension=3000;
    
       NSLog(@" ----------averagePrice!!!");
    self.government.averagePrice=10;
 
   
   // Уровень МАСТЕР. (Не получился мастер,классы кроме AppDelagate не работают!!!)
    
  //  7. Подпишите классы на нотификацию ухода приложения в бекграунд, чтобы когда нажимается кнопка HOME и приложение сворачивается, каждый объект заявлял о том что он идет спать
//  8. Тоже самое сделать для случая, когда приложение возвращается из свернутого состояния
    
//Жени код на мастера http://vk.com/topic?act=browse_images&id=-58860049_2821
   
 
    // Уровень  СУПЕРМЕН.
    
 //  9. Создайте свой класс аналог апп делегату, только он не делегат приложения, но слушатель тех же самых нотификаций, какие методы есть у делегата. Грубо говоря у вашего класса должны быть теже методы, что и у апп делегата, но вызываться они должны путем нотификаций.
 //  10. Добавьте НСЛоги в каждый метод апп делегата и своего класса.
//   11. Сворачивая и разварачивая приложение добивайтесь вызовов определенный методов делегата и тех же нотификаций и посмотрите что вызывается раньше - метод делегата или нотификация :)
     //Жени код на Супермен http://vk.com/topic?act=browse_images&id=-58860049_2822 показать ЖЕНИ!!!http://prntscr.com/8tyd9v
    
    
    return YES;
}

-(void) governmentNotification:(NSNotification*) notification {
   // NSLog(@"governmentNotification userInfo=%@",notification.userInfo);
   
    //принимает обьект класса NSNotification
    
}
-(void) dealloc {//отключаем подписку.
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    //[[NSNotificationCenter defaultCenter] removeObserver:self name:AGGovernmentTaxLevelDidChengeNotification object:nil];  //--либо по названию
    
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    NSLog(@"AppDelegate: It is UIApplicationWillResignActiveNotification");
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
      NSLog(@"AppDelegate: It is UIApplicationDidEnterBackgroundNotification");
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
      NSLog(@"AppDelegate: It is UIApplicationWillEnterForegroundNotification");
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    NSLog(@"AppDelegate: It is UIApplicationDidBecomeActiveNotification");
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
     NSLog(@"AppDelegate: It is UIApplicationWillTerminateNotification");
}

@end
