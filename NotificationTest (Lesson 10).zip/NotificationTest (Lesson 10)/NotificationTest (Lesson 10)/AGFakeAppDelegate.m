//
//  AGFakeAppDelegate.m
//  NotificationTest (Lesson 10)
//
//  Created by Anton Gorlov on 25.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGFakeAppDelegate.h"
#import "AGGovernment.h"
@implementation AGFakeAppDelegate
//Уровень  СУПЕРМЕН (Не получился супермен,классы кроме AppDelagate не работают!!!)
- (instancetype)init
{
    self = [super init];
    if (self) {
        [[NSNotificationCenter defaultCenter]addObserver:self
                                                selector:@selector(didFinishLaunchingWithOptions:)
                                                    name:UIApplicationDidFinishLaunchingNotification
         //не работает UIApplicationDidFinishLaunchingNotification предлагает NSExtensionHostDidFinishLaunchingNotification
                                                  object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(applicationWillResignActive:)
                                                     name:NSExtensionHostWillResignActiveNotification
                                                   object:nil];
        [[NSNotificationCenter defaultCenter]addObserver:self
                                                selector:@selector(applicationDidEnterBackground:)
                                                    name:NSExtensionHostDidEnterBackgroundNotification
                                                  object:nil];
        [[NSNotificationCenter defaultCenter]addObserver:self
                                                selector:@selector(applicationWillEnterForeground:)
                                                    name:NSExtensionHostWillEnterForegroundNotification
                                                  object:nil];
        [[NSNotificationCenter defaultCenter]addObserver:self
                                                selector:@selector(applicationDidBecomeActive:)
                                                    name:NSExtensionHostDidBecomeActiveNotification
                                                  object:nil];
        [[NSNotificationCenter defaultCenter]addObserver:self
                                                selector:@selector(applicationWillTerminate:)
                                                    name:NSExtensionHostWillTerminateNotification
                                                  object:nil];
    }
    return self;
}
-(void) dealloc{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}
-(void)didFinishLaunchingWithOptions:(NSNotificationCenter*)notification{
    NSLog(@"Fake appDelegate: It is UIApplicationDidFinishLaunchingNotification");
    NSLog(@" ");
}
- (void)applicationWillResignActive:(NSNotification *)application
{
    NSLog(@"Fake appDelegate: It is UIApplicationWillResignActiveNotification");
    NSLog(@" ");
}

- (void)applicationDidEnterBackground:(NSNotification *)application
{
    NSLog(@"Fake appDelegate: It is UIApplicationDidEnterBackgroundNotification");
    NSLog(@" ");
}

- (void)applicationWillEnterForeground:(NSNotification *)application
{
    NSLog(@"Fake appDelegate: It is UIApplicationWillEnterForegroundNotification");
    NSLog(@" ");
}

- (void)applicationDidBecomeActive:(NSNotification *)application
{
    NSLog(@"Fake appDelegate: It is UIApplicationDidBecomeActiveNotification");
    NSLog(@" ");
}

- (void)applicationWillTerminate:(NSNotification *)application
{
    NSLog(@"Fake appDelegate: It is UIApplicationWillTerminateNotification");
    NSLog(@" ");
}

@end



