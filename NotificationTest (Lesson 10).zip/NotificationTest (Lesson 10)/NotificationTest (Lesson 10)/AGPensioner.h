//
//  AGPensioner.h
//  NotificationTest (Lesson 10)
//
//  Created by Anton Gorlov on 19.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGPensioner : NSObject
@property (assign,nonatomic)float pension; //пенсия
@property (assign,nonatomic)float averagePrice; // средняя цена на товар
@property (assign,nonatomic)float inflationRatePrice; //инфляция
@property (assign,nonatomic)float pensionIncrease;

@end
