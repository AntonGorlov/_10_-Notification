//
//  AGGovernment.h
//  NotificationTest (Lesson 10)
//
//  Created by Anton Gorlov on 19.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString*const AGGovernmentTaxLevelDidChangeNotification;
extern NSString*const AGGovernmentSalaryDidChangeNotification;
extern NSString*const AGGovernmentPensionDidChangeNotification;
extern NSString*const AGGovernmentAveragePriceDidChangeNotification;

extern NSString*const AGGovernmentTaxLevelUserInfoKey;
extern NSString*const AGGovernmentSalaryUserInfoKey;
extern NSString*const AGGovernmentPensionUserInfoKey;
extern NSString*const AGGovernmentAveragePriceUserInfoKey;

@interface AGGovernment : NSObject

@property (assign,nonatomic) float taxLevel;  //уровень налогов
@property (assign,nonatomic) float salary;   //з/п
@property (assign,nonatomic) float pension; //пенсия
@property (assign,nonatomic) float averagePrice;  //средняя цена на товары
@end
