//
//  AGDoctor.m
//  NotificationTest (Lesson 10)
//
//  Created by Anton Gorlov on 19.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGDoctor.h"
#import "AGGovernment.h"

@implementation AGDoctor

#pragma mark ---Initialization---
- (instancetype)init
{
    self = [super init];
    if (self) {
        NSNotificationCenter*nc=[NSNotificationCenter defaultCenter];
        //доктору только зарплата и сред цена нужна,подпишемся на нотификацию
        [nc addObserver:self//обьект
               selector:@selector(salaryChangedNotification:)//метод
                   name:AGGovernmentSalaryDidChangeNotification object:nil]; //подписали на зп
        
        [nc addObserver:self
               selector:@selector(averagePriceChangedNotification:)
                   name:AGGovernmentAveragePriceDidChangeNotification object:nil]; //подписали на среднюю зп.
        
        //сворачиваем приложение
        [[NSNotificationCenter defaultCenter]addObserver:self
                                                selector:@selector(didEnterBackgroundNotification:)
                                                    name:NSExtensionHostDidEnterBackgroundNotification
                                                  object:nil];
        //разворачиваем приложение
        [[NSNotificationCenter defaultCenter]addObserver:self
                                                selector:@selector(willEnterForegroundNotification:)
                                                    name:NSExtensionHostWillEnterForegroundNotification
                                                  object:nil];
        
    }
    return self;
}
-(void) dealloc { //ОБЯЗАТЕЛЬНО!!!отписываться можно тут же
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void) didEnterBackgroundNotification:(NSNotification*) notification {
    NSLog(@"Doctor goes to sleep");
}
-(void) willEnterForegroundNotification:(NSNotification*) notification {
    NSLog(@"Doctor woke up");
}


#pragma mark ---Notification---
//реализуем 2 метода
-(void) salaryChangedNotification:(NSNotification*) notification { //обробатываем
    NSNumber*value=[notification.userInfo objectForKey:AGGovernmentSalaryUserInfoKey];
    float salary=[value floatValue];
    if (salary>self.salary) {
        NSLog(@"Doctors are happy");
    }else {
        NSLog(@"Doctors are NOT happy");
    }
    self.salary=salary;
    
}
-(void) averagePriceChangedNotification:(NSNotification*) notification {
        NSNumber*value=[notification.userInfo objectForKey:AGGovernmentAveragePriceUserInfoKey];
        float averagePrice=[value floatValue];
        if (averagePrice<self.averagePrice) {
            NSLog(@"Doctors can buy something");
        }else {
            NSLog(@"Doctors can't buy something!");
        }
        self.averagePrice=averagePrice;
}




@end
