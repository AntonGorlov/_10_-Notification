//
//  AGPensioner.m
//  NotificationTest (Lesson 10)
//
//  Created by Anton Gorlov on 19.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGPensioner.h"
#import "AGGovernment.h"

@implementation AGPensioner

- (instancetype)init
{
    self = [super init];
    if (self) {
        NSNotificationCenter* nc=[NSNotificationCenter defaultCenter];//пенсионерам нужен уровень пенсии.
        [nc addObserver:self
               selector:@selector(pensionDidChangeNotification:)
                   name:AGGovernmentPensionDidChangeNotification
                 object:nil];
        [nc addObserver:self
               selector:@selector(averagePriceChangedNotification:) //selector: - это реализованый ниже метод.
                   name:AGGovernmentAveragePriceDidChangeNotification
                 object:nil];//средняя цена на товар
        //сворачиваем приложение
        [[NSNotificationCenter defaultCenter]addObserver:self
                                                selector:@selector(willResignActiveNotification:)
                                                    name:NSExtensionHostWillResignActiveNotification
                                                  object:nil];
        //разворачиваем приложение
        [[NSNotificationCenter defaultCenter]addObserver:self
                                                selector:@selector(didBecomeActiveNotification:)
                                                    name:NSExtensionHostDidBecomeActiveNotification
                                                  object:nil];
       
        [[NSNotificationCenter defaultCenter]addObserver:self
                                                selector:@selector(yourMethod)
                                                    name:@"appDidBecomeActive"
                                                  object:nil];
        
        
    }
    return self;
 

}
-(void) dealloc {
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}


- (void)yourMethod {NSLog(@"aaaaaaa");}

- (void)willResignActiveNotification:(NSNotification *)notification {
       NSLog(@"Pensioner: It is UIApplicationDidEnterBackgroundNotification");
}

- (void)didBecomeActiveNotification:(NSNotification*)notification {
        NSLog(@"Pensioner: It is UIApplicationWillEnterForegroundNotification");
}





#pragma mark --Notification--
/* Уровень Ученик
-(void) pensionDidChangeNotification:(NSNotification*) notification{
    NSNumber*value=[notification.userInfo objectForKey:AGGovernmentPensionUserInfoKey];
    float pension=[value floatValue];
    if (pension>self.pension) {
        NSLog(@"Pensioners are happy!");
    }else {
        NSLog(@"Pensioners are NOT happy");
    }
    self.pension=pension;
}

-(void) averagePriceChangedNotification:(NSNotification*) notification {
    NSNumber*value=[notification.userInfo objectForKey:AGGovernmentAveragePriceUserInfoKey];
    float averagePrice=[value floatValue];
    if (averagePrice<self.averagePrice) {
        NSLog(@"Pensioners can buy something");
    }else {
        NSLog(@"Pensioners can't buy something!");
    }
    self.averagePrice=averagePrice;
}
 */
//Уровень Умничка http://vk.com/topic?act=browse_images&id=-58860049_375
-(void) pensionDidChangeNotification:(NSNotification*) notification{
    
    NSNumber*value=[notification.userInfo objectForKey:AGGovernmentPensionUserInfoKey];
    float pension=[value floatValue];
    _pensionIncrease=(pension/(self.pension/100))-100; //pension -новая пенсия,а self.pension -старая.
    if (_pensionIncrease < 0) {
        NSLog(@"Pensioners NOT happy! Pension increased by %.2f%%",_pensionIncrease);
    }else {
        NSLog(@"Pensioners are  happy! Pension increased by %.2f%%",_pensionIncrease);
    }
    self.pension=pension;
}

-(void) averagePriceChangedNotification:(NSNotification*) notification {
    NSNumber*value=[notification.userInfo objectForKey:AGGovernmentAveragePriceUserInfoKey];
    float averagePrice=[value floatValue];
    _inflationRatePrice=(averagePrice/(self.averagePrice/100))-100;
    if (_inflationRatePrice > 0 && _pensionIncrease < 0) {
        NSLog(@"Pensioners says :Our government is stupid!");
    }else if(_inflationRatePrice < 0 && _pensionIncrease > 0) {
        NSLog(@"Pensioners says : Our government is excellent");
    }else {
        NSLog(@"Pensioners says : Our government is not bad");
    }
    self.averagePrice=averagePrice;
}

@end
