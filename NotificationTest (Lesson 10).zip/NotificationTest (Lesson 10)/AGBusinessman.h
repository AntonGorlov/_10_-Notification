//
//  AGBusinessman.h
//  NotificationTest (Lesson 10)
//
//  Created by Anton Gorlov on 19.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGBusinessman : NSObject
@property (assign,nonatomic)float taxLevel;
@property (assign,nonatomic)float averagePrice;
@property (assign,nonatomic)float inflationRatePrice;
@property (assign,nonatomic)float taxLevelIncrease;
@end
