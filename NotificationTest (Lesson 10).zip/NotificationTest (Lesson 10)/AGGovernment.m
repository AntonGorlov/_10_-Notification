//
//  AGGovernment.m
//  NotificationTest (Lesson 10)
//
//  Created by Anton Gorlov on 19.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGGovernment.h"

NSString*const AGGovernmentTaxLevelDidChangeNotification=@"AGGovernmentTaxLevelDidChangeNotification";
NSString*const AGGovernmentSalaryDidChangeNotification=@"AGGovernmentSalaryDidChangeNotification";
NSString*const AGGovernmentPensionDidChangeNotification=@"AGGovernmentPensionDidChangeNotification";
NSString*const AGGovernmentAveragePriceDidChangeNotification=@"AGGovernmentAveragePriceDidChangeNotification";

NSString*const AGGovernmentTaxLevelUserInfoKey=@"AGGovernmentTaxLevelUserInfoKey";
NSString*const AGGovernmentSalaryUserInfoKey=@"AGGovernmentSalaryUserInfoKey";
NSString*const AGGovernmentPensionUserInfoKey=@"AGGovernmentPensionUserInfoKey";
NSString*const AGGovernmentAveragePriceUserInfoKey=@"AGGovernmentAveragePriceUserInfoKey";

@implementation AGGovernment

- (instancetype)init
{
    self = [super init];
    if (self) {
        _taxLevel=5.f; //стартовые показатели налога и т.д.
        _salary=1000;
        _pension=500;
        _averagePrice=10.f; //средняя цена на товар
        
        //сворачиваем приложение
        [[NSNotificationCenter defaultCenter]addObserver:self
                                                selector:@selector(didEnterBackgroundNotification:)
                                                    name:NSExtensionHostDidEnterBackgroundNotification
                                                  object:nil];
        [[NSNotificationCenter defaultCenter]addObserver:self
                                                selector:@selector(willEnterForegroundNotification:)
                                                    name:NSExtensionHostWillEnterForegroundNotification
                                                  object:nil];

    
    }
    return self;
}

#pragma mark - Notification
-(void) didEnterBackgroundNotification:(NSNotification*) notification {
    NSLog(@"Government goes to sleep");
}
-(void) willEnterForegroundNotification:(NSNotification*) notification {
    NSLog(@"Government woke up");
}
#pragma mark-Setters
-(void) setTaxLevel:(float)taxLevel { //переопределим сеттеры
    _taxLevel=taxLevel; // когда кто-то хочет изменить наш taxLevel (внутр переменная)
    
    NSDictionary*dictionary=[NSDictionary dictionaryWithObject:[NSNumber numberWithFloat:taxLevel] forKey:AGGovernmentTaxLevelUserInfoKey]; //Так как taxLevel-это приметивный тип,то через оболочку NSNumber
    
    [[NSNotificationCenter defaultCenter] postNotificationName:AGGovernmentTaxLevelDidChangeNotification object:nil
        userInfo:dictionary];
    //каждый раз когда мы будем менять эту переменную -будем отправлять notification. В userInfo нужно запихнуть NSDictionary по ключу.
}

-(void) setSalary:(float)salary { //изменилась зп
    _salary=salary;
    NSDictionary*dictionary=[NSDictionary dictionaryWithObject:[NSNumber numberWithFloat:salary] forKey:AGGovernmentSalaryUserInfoKey];
    [[NSNotificationCenter defaultCenter] postNotificationName:AGGovernmentSalaryDidChangeNotification
        object:nil
        userInfo:dictionary]; //посылаем нотификацию ,что з/п изменилась
    
}

-(void) setPension:(float)pension {
    _pension=pension;
    NSDictionary*dictionary=[NSDictionary dictionaryWithObject:[NSNumber numberWithFloat:pension] forKey:AGGovernmentPensionUserInfoKey];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:AGGovernmentPensionDidChangeNotification
         object:nil
         userInfo:dictionary];
}
-(void) setAveragePrice:(float)averagePrice {
    _averagePrice=averagePrice;
    NSDictionary*dictionary=[NSDictionary dictionaryWithObject:[NSNumber numberWithFloat:averagePrice] forKey:AGGovernmentAveragePriceDidChangeNotification];
    
    [[NSNotificationCenter defaultCenter]postNotificationName:AGGovernmentAveragePriceDidChangeNotification object:nil
        userInfo:dictionary];
}



@end
